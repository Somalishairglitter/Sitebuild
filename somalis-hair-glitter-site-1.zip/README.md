# Somali's Hair Glitter Gel website

A responsive static website prepared for GitHub Pages and the custom domain `somalishairglitter.com`.

## Upload to GitHub
1. Create a new public repository, for example `somalis-hair-glitter`.
2. Upload **all files and folders from this package**, keeping the `assets/images` folder structure.
3. Open the repository **Settings**, then **Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.

## Connect the custom domain
1. In GitHub Pages settings, enter `somalishairglitter.com` under **Custom domain** and save.
2. At the domain registrar, add the DNS records shown in GitHub's current custom-domain instructions.
3. After DNS is recognized, enable **Enforce HTTPS** in GitHub Pages settings.

The included `CNAME` file already contains the domain name.

## Edit contact links
Contact details and Facebook ordering links are in `index.html`. Search for:
- `Guadalupegomez7000@gmail.com`
- `http://www.facebook.com/share/1DHeEonE5r/?mibextid=wwXlfr`

## Files
- `index.html`: website content
- `styles.css`: colors, layout, responsive design
- `script.js`: mobile menu and automatic copyright year
- `assets/images/`: optimized WebP versions of the supplied images
- `CNAME`: GitHub Pages custom domain
- `.nojekyll`: prevents unnecessary Jekyll processing
